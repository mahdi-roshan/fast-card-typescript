import RouteContainer from "./routes/routeContainer";


function App() {
  return (
    <RouteContainer />
  );
}

export default App;
