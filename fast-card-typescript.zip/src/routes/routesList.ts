export enum RoutesList {
    fastCard = "/fastcard/:productId",
    invoice = "/fastcard/invoice"
}